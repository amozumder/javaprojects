package EmailApp;

import java.security.SecureRandom;

/**
 * Email application, Udemy Project 1
 *
 * @author Abhijit Mozumder
 * @version 0.1 2019-09-14
 */
public class Email {
    //State variables
    private String firstName;
    private String lastName;
    private String department;
    private String passwd;
    private int mailboxSize;
    private String emailPrimary;

    //Final fields for generating the random password & defaults
    private static final String charLower = "abcdefghijklmnopqrstuvxxyz";
    private static final String charUpper = charLower.toUpperCase();
    private static final String number = "123456789";
    private static final String stringKey = charLower+charUpper+number;
    private static SecureRandom random = new SecureRandom();
    private static final int pwdLength = 8;
    private static final int mailboxSizeDefaultMB = 512;


    //Constructor
    public Email(String firstName, String lastName, String department) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.department = department;
        this.passwd = "";
        this.mailboxSize = mailboxSizeDefaultMB;
        this.emailPrimary = "";
    }

    public String getEmailPrimary() {
        return emailPrimary;
    }

    public int getMailboxSize() {
        return mailboxSize;
    }

    public String getPasswd() {
        return passwd;
    }

    //Set the primary email
    public void setEmailPrimary(String altEmail) {
        String emailString = "";
        if (altEmail.trim().equals("")) {
            emailString = firstName.toLowerCase()+"."+lastName.toLowerCase();
        } else {
            emailString = altEmail;
        }

        String domainString = "company.com";
        if (!"".equals(department)) {
            domainString = department.toLowerCase() + "." + domainString;
        }
        this.emailPrimary = emailString + "@" + domainString;
    }


    //Set Random password
    public void setPasswd() {
        this.passwd = generatePasswd(pwdLength);
    }

    //Set password manually
    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    //Generate random password
    private final String generatePasswd(int pwdLenght) {
        StringBuilder pwd = new StringBuilder(pwdLenght);
        for (int i=0;i<pwdLenght;i++) {
            int randomPosition = random.nextInt(stringKey.length());
            char randomChar = stringKey.charAt(randomPosition);
            pwd.append(randomChar);
        }
        return pwd.toString();

    }
}
