package EmailApp;

import java.util.Scanner;

public class EmailTest {
    public static void main(String[] args) {
        //Get employee details
        Scanner inputConsole = new Scanner(System.in);
        System.out.println("Enter your first name: ");
        String first = inputConsole.next();
        System.out.println("Enter your last name: ");
        String last = inputConsole.next();
        System.out.println("Enter your department: ");
        String dept = inputConsole.next();

        //Create Employee Object
        Email employee = new Email(first, last, dept);

        //Auto generate email
        employee.setEmailPrimary("");

        //Auto generate password
        employee.setPasswd();

        System.out.println("Email for employee is: " + employee.getEmailPrimary() + ", password is: " + employee.getPasswd() + ", mailbox size is: " + employee.getMailboxSize() + " MB");

        //Offer to change the email address
        System.out.println("Please enter a different email (Enter No if your are happy with the current one)");
        String altEmail = inputConsole.next();

        //Set alternate email
        if (!altEmail.equals("No")) {
            employee.setEmailPrimary(altEmail);
        }

        //Offer to change the password
        System.out.println("Please enter a new password (8 characters): ");
        String newPwd = inputConsole.next();

        if (newPwd.length() != 8) {
            System.out.println("Please enter 8 character password");
        } else {
            //Set the new password
            employee.setPasswd(newPwd);
        }

        System.out.println("Email for employee is: " + employee.getEmailPrimary() + ", password is: " + employee.getPasswd() + ", mailbox size is: " + employee.getMailboxSize() + " MB");


    }
}
