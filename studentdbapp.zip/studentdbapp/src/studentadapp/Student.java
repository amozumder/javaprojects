package studentadapp;

import java.util.ArrayList;
import java.util.Arrays;

public class Student {
    //Define the class state
    private String firstName;
    private String lastName;
    private int yearOfStudent;
    private int studentId;
    private static int nextId = 1;
    private String[] courseListStudent;
    private double studentFees;
    private double studentPayment;

    //Define the final variables
    private final double courseFee = 600.0;


    public Student(String firstName, String lastName, int yearOfStudent) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.yearOfStudent = yearOfStudent;
        this.studentId = 0;
    }

    public int getYearOfStudent() {
        return yearOfStudent;
    }

    public int getStudentId() {
        return studentId;
    }


    public double getStudentFees() {
        return studentFees;
    }

    public double getStudentBalance() {
        return studentFees - studentPayment;
    }


    public void setStudentId(int stdIdLength) {
        int id = nextId;
        int lengthOfId = String.valueOf(id).length();
        int lengthOfPadding = (stdIdLength - lengthOfId) - 1;
        String paddingForId = "";

        for (int counter = 1; counter <= lengthOfPadding; counter++) {
            paddingForId += "0";
        }

        this.studentId = Integer.parseInt(String.valueOf(yearOfStudent) + paddingForId + String.valueOf(id));
        nextId++;

    }



    public void enrollCourse(int nbrOfCourse, String listOfCourse[]) {
        courseListStudent = new String[nbrOfCourse];
        for (int count = 0; count < nbrOfCourse; count++) {
            courseListStudent[count] = listOfCourse[count];
        }
    }

    public void setStudentFees() {
        this.studentFees = courseListStudent.length*courseFee;
    }

    public void setStudentPayment(double studentPayment) {
        this.studentPayment = studentPayment;
    }

    public String showStudentStatus() {
        return " Name of student: "+ firstName + " " + lastName +"\n Id: " + studentId + "\n Courses Enrolled: " + Arrays.toString(courseListStudent) + "\n Balance: " + getStudentBalance();
    }


}
