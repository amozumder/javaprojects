package studentadapp;

import java.util.Arrays;
import java.util.Scanner;

public class StudentDBApp {
    public static void main(String[] args) {
        //State variables
        final int stdIdLength = 5;
        int numberOfStudents = 0;
        String firstName = "";
        String lastName = "";
        int yearOfStd = 0;

        Scanner input = new Scanner(System.in);
        System.out.println("How many number of students do you want to enter: ");
        numberOfStudents = input.nextInt();

        if (numberOfStudents > 0) {
            Student[] pupil = new Student[numberOfStudents];
            for (int counter = 0; counter < numberOfStudents; counter++) {
                //Initialize variables
                firstName = "";
                lastName = "";
                yearOfStd = 0;

                System.out.println("Enter details of student # " + (counter + 1) + " ");
                System.out.print("Enter Student First Name: ");
                firstName = input.next();
                System.out.print("Enter Student Last Name: ");
                lastName = input.next();
                System.out.print("Enter Year of Student: ");
                yearOfStd = input.nextInt();

                pupil[counter] = new Student(firstName, lastName, yearOfStd);
                pupil[counter].setStudentId(stdIdLength);

                //Enter number of courses for the student
                int nbrOfCourses = 0;
                System.out.print("Enter number of courses: ");
                nbrOfCourses = input.nextInt();
                if (nbrOfCourses > 0) {
                    System.out.println("Enter courses: History_101; Mathematics_101; English_101; Chemistry_101; Computer_Science_101");
                    String[] course = new String[nbrOfCourses];
                    for (int i = 0; i < nbrOfCourses; i++) {
                        System.out.print("Enter Course # " + (i + 1) + " :");
                        course[i] = input.next();
                    }
                    pupil[counter].enrollCourse(nbrOfCourses, course);

                }

                //Show the student balance:
                pupil[counter].setStudentFees();
                System.out.println("Your fees for enrolled courses are: " + pupil[counter].getStudentFees());

                //Payment of student fees
                System.out.print("Would you like to make a payment (Y/N): ");
                String paymFlag = input.next();

                if (paymFlag.equals("Y")) {
                    System.out.print("Enter payment amount: ");
                    double payment = input.nextDouble();
                    pupil[counter].setStudentPayment(payment);
                }
            }
            //Show student status
            for (Student p : pupil
            ) {
                System.out.println(p.showStudentStatus());
            }
        }
    }
}
